import React from 'react'
import { Typography } from '@mui/material'

function Paso2C() {
    return (
        <Typography
        variant="body1"
        sx={{ mb: 2, fontWeight: "bold", color: "#00673D", p: 2}}
      >
      C. En el asunto del correo especificar SOLICITUD DE CONSTANCIA DE VERIFICACIÓN DE DOCUMENTOS PARA TITULACIÓN
      </Typography>
      )
}

export default Paso2C
