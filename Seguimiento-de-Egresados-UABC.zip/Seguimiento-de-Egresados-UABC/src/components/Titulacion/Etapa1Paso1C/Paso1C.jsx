import React from 'react'
import { Typography } from '@mui/material'

function Paso1C() {
  return (
    <Typography
    variant="body1"
    sx={{ mb: 2, fontWeight: "bold", color: "#00673D", p: 2}}
  >
   C. En el asunto del correo especificar SOLICITUD DE CEP Y CP
  </Typography>
  )
}

export default Paso1C